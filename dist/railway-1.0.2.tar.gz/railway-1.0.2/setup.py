# fly on rails setup.py
from distutils.core import setup
setup(
    name = "railway",
    packages = ["httplib2"],
    version = "1.0.2")
